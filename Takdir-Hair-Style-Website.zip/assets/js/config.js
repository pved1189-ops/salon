/**
 * =========================================================================
 * TAKDIR HAIR STYLE - SALON CONFIGURATION FILE
 * =========================================================================
 * You can edit all your salon details in this ONE single file!
 * Any changes made here will automatically reflect across ALL pages:
 * - index.html (Home)
 * - about.html (About Us)
 * - services.html (Services)
 * - our-work.html (Our Work / Gallery)
 * - contact.html (Contact Us)
 * =========================================================================
 */

const SALON_CONFIG = {
  // 1. BUSINESS NAME
  salonName: "Takdir Hair Style",
  tagline: "Your Style. Your Confidence. Your Takdir.",

  // 2. PHONE NUMBER (FOR CLICK-TO-CALL)
  // Format for calling: Include country code without spaces (e.g., "+919876543210")
  phoneNumber: "YOUR_PHONE_NUMBER",
  // Display format shown to users on screen (e.g., "+91 98765 43210")
  phoneDisplay: "[Your Phone Number]",

  // 3. WHATSAPP NUMBER (FOR BOOKINGS & DIRECT CHATS)
  // Format for WhatsApp link: Digits ONLY, include country code, NO plus sign, NO dashes or spaces
  // Example for India: "919876543210", Example for US: "15551234567"
  whatsappNumber: "YOUR_WHATSAPP_NUMBER",
  // Display format shown to users on screen
  whatsappDisplay: "[Your WhatsApp Number]",

  // 4. EMAIL ADDRESS
  email: "YOUR_EMAIL@domain.com",
  emailDisplay: "[Your Email]",

  // 5. SALON ADDRESS
  address: "[Your Salon Address, Street, City, State - PIN/ZIP Code]",

  // 6. OPENING HOURS
  openingHours: "Monday - Sunday: 9:00 AM - 9:00 PM",
  openingHoursShort: "Mon - Sun: 9 AM - 9 PM",

  // 7. SOCIAL MEDIA URLS (Replace with your actual profile links)
  instagramUrl: "YOUR_INSTAGRAM_URL", // e.g., "https://instagram.com/takdirhairstyle"
  facebookUrl: "YOUR_FACEBOOK_URL",   // e.g., "https://facebook.com/takdirhairstyle"
  youtubeUrl: "YOUR_YOUTUBE_URL",     // e.g., "https://youtube.com/@takdirhairstyle"

  // 8. GOOGLE MAPS EMBED URL
  // To get your embed URL:
  // 1. Open Google Maps (maps.google.com) and search your salon location
  // 2. Click "Share" -> "Embed a map" -> copy only the 'src="..."' link
  // 3. Paste it below inside the quotes
  googleMapsEmbedUrl: "YOUR_GOOGLE_MAPS_EMBED_URL",

  // 9. WEBSITE DOMAIN (For canonical URLs, sitemaps, and sharing)
  domainUrl: "https://YOURDOMAIN.com/",

  // 10. DEFAULT WHATSAPP PRE-FILLED MESSAGES
  defaultWhatsappMessage: "Hello Takdir Hair Style, I would like to book an appointment.",
  serviceInquiryMessage: "Hello Takdir Hair Style, I would like to know more about your services."
};

// Export to window object for browser access
if (typeof window !== "undefined") {
  window.SALON_CONFIG = SALON_CONFIG;
}
